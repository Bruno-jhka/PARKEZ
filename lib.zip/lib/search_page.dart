import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:icon_badge/icon_badge.dart';
import 'package:parkez/controllers/app_controller.dart';
import 'package:parkez/estabelecimentos/Admin_estabelecimentos/AdminPage_establecimentos.dart';
import 'package:parkez/estabelecimentos/EstacionamentoPageReserve.dart';
import 'package:provider/provider.dart';
import '_Comum/int_state.dart';

class SearchPage extends StatefulWidget {
  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  TextEditingController _searchController = TextEditingController();
  List<String> _searchResults = [];
  List<String> _searchHistory = [];
  String searchQuery = '';

  @override
  Widget build(BuildContext context) {
    final intState = Provider.of<IntState>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Pesquisar'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              decoration: InputDecoration(
                labelText: 'Pesquisar Estabelecimento',
                suffixIcon: Icon(Icons.search),
              ),
              onChanged: (value) {
                setState(() {
                  searchQuery = value;
                });
              },
            ),
            SizedBox(height: 20),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('estabelecimentos')
                    .where('nome', isGreaterThanOrEqualTo: searchQuery)
                    .where('nome', isLessThanOrEqualTo: '$searchQuery\uf8ff')
                    .snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return Center(child: CircularProgressIndicator());
                  }
                  var docs = snapshot.data!.docs;
                  return ListView.builder(
                    itemCount: docs.length,
                    itemBuilder: (context, index) {
                      var doc = docs[index];
                      var data = doc.data() as Map<String, dynamic>;
                      return ListTile(
                        title: Text(data['nome']),
                        subtitle: Text(data['endereco']),
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) => PagEstabelecimentoReserve(
                                  estabelecimentoId: data['nome']),
                            ),
                          );
                        },
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        height: 45,
        color: AppController.instance.isDarkTheme
            ? Colors.grey[950]
            : Colors.white,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Expanded(
              child: IconButton(
                icon: Icon(Icons.home),
                onPressed: () {
                  Navigator.of(context).pushReplacementNamed('/home');
                },
              ),
            ),
            Expanded(
              child: IconButton(
                icon: Icon(Icons.search),
                onPressed: () {
                  //Navigator.pushReplacementNamed(context, '/search');
                },
              ),
            ),
            Expanded(
              child: IconBadge(
                icon: Icon(Icons.account_circle),
                itemCount: intState.value,
                right: 17,
                badgeColor: Colors.red,
                itemColor: Colors.white,
                hideZero: true,
                onTap: () {
                  Navigator.of(context).pushReplacementNamed('/user');
                  print('test');
                },
              ),
            ),
            Expanded(
              child: IconButton(
                icon: Icon(Icons.settings),
                onPressed: () {
                  Navigator.pushReplacementNamed(context, '/settings');
                  // Implemente a navegação para a tela de Configurações
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _search(String query) {
    // Simulação de uma pesquisa em uma base de dados
    List<String> mockData = [
      'Burguer King', 'Academia Pratique', 'Estacionamento Mineirao',
      'Shopping Contagem' // Apenas um item cadastrado para teste
    ];

    // Limpa a lista de resultados de pesquisa
    _searchResults.clear();

    // Filtra os dados baseados na consulta
    for (String item in mockData) {
      if (item.toLowerCase().contains(query.toLowerCase())) {
        _searchResults.add(item);
      }
    }

    // Atualiza a UI
    setState(() {});
  }

  void _addToHistory(String item) {
    // Adiciona o item ao histórico somente se ainda não estiver presente
    if (!_searchHistory.contains(item)) {
      _searchHistory.add(item);
      // Limita o histórico a 3 itens
      if (_searchHistory.length > 3) {
        _searchHistory.removeAt(0); // Remove o item mais antigo do histórico
      }
    }
  }
}
