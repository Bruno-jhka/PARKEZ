import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'dart:async';
import 'package:url_launcher/url_launcher.dart';
import 'package:parkez/servicos/vagas_user_servico.dart';
import 'package:permission_handler/permission_handler.dart';

class PagEstabelecimentoReserve extends StatefulWidget {
  final String estabelecimentoId;

  PagEstabelecimentoReserve({required this.estabelecimentoId});

  @override
  _ReservePageState createState() => _ReservePageState();
}

class _ReservePageState extends State<PagEstabelecimentoReserve> {
  int vagasDisponiveis = 0;
  String endereco = '';
  String nome = '';
  String descricao = '';
  String imageUrl = '';
  String preco = "0.0";
  Timer? _timer;
  Duration _timeRemaining = Duration();

  @override
  void initState() {
    super.initState();
    _requestPermissions();
    _fetchEstabelecimentoInfo();
    _checkActiveReservation();
  }

  Future<void> _requestPermissions() async {
    var status = await Permission.locationWhenInUse.status;
    if (!status.isGranted) {
      status = await Permission.locationWhenInUse.request();
      if (!status.isGranted) {
        // Permissão não concedida. Informe o usuário.
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Permissão necessária'),
            content: Text(
                'Este aplicativo precisa da permissão de localização para funcionar corretamente.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text('OK'),
              ),
            ],
          ),
        );
      }
    }
  }

  Future<void> _fetchEstabelecimentoInfo() async {
    var doc = await FirebaseFirestore.instance
        .collection('estabelecimentos')
        .doc(widget.estabelecimentoId)
        .get();
    setState(() {
      vagasDisponiveis = doc['vagas'];
      endereco = doc['endereco'];
      nome = doc['nome'];
      descricao = doc['descricao'];
      imageUrl = doc['imageUrl'];
      preco = doc['preco'];
    });
  }

  Future<void> _checkActiveReservation() async {
    var user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      var uid = user.uid;
      var now = DateTime.now();
      var firestore = FirebaseFirestore.instance;
      var userReservations = await firestore
          .collection('Usuarios')
          .doc(uid)
          .collection('vagas')
          .where('expirationTime', isGreaterThan: now.toIso8601String())
          .get();
      if (userReservations.docs.isNotEmpty) {
        var reservation = userReservations.docs.first;
        var expirationTime = DateTime.parse(reservation['expirationTime']);
        setState(() {
          _timeRemaining = expirationTime.difference(now);
        });
        _startTimer(expirationTime, uid, reservation.id);
      }
    }
  }

  void _startTimer(DateTime expirationTime, String uid, String reservationId) {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) async {
      var now = DateTime.now();
      if (now.isBefore(expirationTime)) {
        setState(() {
          _timeRemaining = expirationTime.difference(now);
        });
      } else {
        timer.cancel();
        setState(() {
          _timeRemaining = Duration();
        });
        await _returnSpot(uid, reservationId);
      }
    });
  }

  Future<void> _returnSpot(String uid, String reservationId) async {
    var firestore = FirebaseFirestore.instance;
    var reservation = await firestore
        .collection('Usuarios')
        .doc(uid)
        .collection('vagas')
        .doc(reservationId)
        .get();
    if (reservation.exists) {
      var estabelecimentoId = reservation['estabelecimentoId'];
      await ReservationManager.returnSpotToEstabelecimento(estabelecimentoId);
      await firestore
          .collection('Usuarios')
          .doc(uid)
          .collection('vagas')
          .doc(reservationId)
          .delete();
    }
  }

  Future<void> _reservarVaga() async {
    var user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      var uid = user.uid;
      await ReservationManager.reserveSpot(
        uid: uid,
        estabelecimentoId: widget.estabelecimentoId,
        vagasDisponiveis: vagasDisponiveis,
        preco: preco,
      );
      await _fetchEstabelecimentoInfo();
      await _checkActiveReservation();
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _launchMaps() async {
    String query = Uri.encodeComponent(endereco);
    String googleMapsUrl =
        "https://www.google.com/maps/search/?api=1&query=$query";
    String appleMapsUrl = "https://maps.apple.com/?q=$query";

    // Tentativa de abrir o Google Maps
    if (await canLaunchUrl(Uri.parse(googleMapsUrl))) {
      await launchUrl(Uri.parse(googleMapsUrl));
    }
    // Tentativa de abrir o Apple Maps como fallback para iOS
    else if (await canLaunchUrl(Uri.parse(appleMapsUrl))) {
      await launchUrl(Uri.parse(appleMapsUrl));
    }
    // Se nenhum app de mapas estiver disponível, tenta abrir no navegador
    else {
      String webUrl = "https://www.google.com/maps/search/?api=1&query=$query";
      if (await canLaunchUrl(Uri.parse(webUrl))) {
        await launchUrl(Uri.parse(webUrl));
      } else {
        throw 'Could not launch $webUrl';
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Reservar Vaga'),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            imageUrl.isNotEmpty
                ? Image.network(
                    imageUrl,
                    height: 200,
                    fit: BoxFit.cover,
                  )
                : Container(height: 200, color: Colors.grey),
            SizedBox(height: 20),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                nome,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            SizedBox(height: 10),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                endereco,
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            ),
            SizedBox(height: 20),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: ElevatedButton(
                onPressed: _launchMaps,
                child: Text('Ver Localização'),
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                descricao,
                style: TextStyle(fontSize: 16),
              ),
            ),
            SizedBox(height: 10),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.star, color: Colors.amber),
                  Icon(Icons.star, color: Colors.amber),
                  Icon(Icons.star, color: Colors.amber),
                  Icon(Icons.star_half, color: Colors.amber),
                  Icon(Icons.star_border, color: Colors.amber),
                ],
              ),
            ),
            SizedBox(height: 20),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                'Vagas disponíveis: $vagasDisponiveis',
                style: TextStyle(fontSize: 16),
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                'Preço: R\$ $preco',
                style: TextStyle(fontSize: 16),
              ),
            ),
            SizedBox(height: 20),
            if (_timeRemaining.inSeconds > 0)
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  'Tempo restante da reserva: ${_timeRemaining.inHours}:${(_timeRemaining.inMinutes % 60).toString().padLeft(2, '0')}:${(_timeRemaining.inSeconds % 60).toString().padLeft(2, '0')}',
                  style: TextStyle(fontSize: 16, color: Colors.red),
                ),
              ),
            if (_timeRemaining.inSeconds == 0)
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: ElevatedButton(
                  onPressed: vagasDisponiveis > 0 ? _reservarVaga : null,
                  child: Text(vagasDisponiveis > 0
                      ? 'Reservar Vaga'
                      : 'Sem Vagas Disponíveis'),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
